#include <iostream>
#include <unistd.h>
#include <ctime>
using namespace std;

int main()
{
    cout << "1" << endl;
    sleep(5);
    cout << "2" << endl;
    return 0;
}
